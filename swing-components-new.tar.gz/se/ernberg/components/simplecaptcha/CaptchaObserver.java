package se.ernberg.components.simplecaptcha;

public interface CaptchaObserver {
	public void textGenerationComplete(long id);
}
